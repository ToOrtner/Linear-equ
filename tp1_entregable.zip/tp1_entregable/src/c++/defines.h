#ifndef DEFINES_H
#define DEFINES_H

#include <vector>
#include <utility>

using namespace std;

typedef double ranking_t;

#define matrix vector<vector<ranking_t>>

#define nat unsigned int

#define FILE_PRESITION 14

const ranking_t precision = 0.0001;

#endif //DEFINES_H
